from django.shortcuts import render
from django.db.models import Count, Avg
from tours.models import Tour, Booking, Country


def home(request):
    context = {
        'tours_count': Tour.objects.filter(is_active=True).count(),
        'countries_count': Country.objects.count(),
        'bookings_count': Booking.objects.count(),
        'popular_tours': (
            Tour.objects.filter(is_active=True)
            .annotate(bookings_count=Count('bookings'))
            .order_by('-bookings_count')[:3]
        ),
    }
    return render(request, 'core/home.html', context)


def stats(request):
    countries = Country.objects.annotate(tours_count=Count('tours'))
    avg_price = Tour.objects.aggregate(avg=Avg('price'))['avg'] or 0
    by_status = Booking.objects.values('status').annotate(n=Count('id'))
    context = {
        'countries': countries,
        'avg_price': avg_price,
        'by_status': by_status,
        'total_bookings': Booking.objects.count(),
    }
    return render(request, 'core/stats.html', context)