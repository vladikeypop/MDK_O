from django.contrib import admin
from .models import Country, Tour, Client, Booking


@admin.register(Country)
class CountryAdmin(admin.ModelAdmin):
    list_display = ('name', 'visa_regime', 'currency')
    search_fields = ('name',)


@admin.register(Tour)
class TourAdmin(admin.ModelAdmin):
    list_display = ('name', 'country', 'duration_days', 'price', 'is_active')
    list_filter = ('country', 'is_active')
    search_fields = ('name',)


@admin.register(Client)
class ClientAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'passport', 'phone', 'email')
    search_fields = ('full_name', 'passport', 'email')


@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ('tour', 'client', 'start_date', 'end_date', 'total_price', 'status')
    list_filter = ('status',)