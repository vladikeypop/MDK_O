# tours/views.py
from decimal import Decimal, InvalidOperation
from datetime import date

from django.shortcuts import render, redirect, get_object_or_404
from django.db import transaction
from django.contrib import messages
from django.urls import reverse

from .models import Tour, Country, Client, Booking


def tour_list(request):
    qs = Tour.objects.select_related('country').filter(is_active=True)
    q = request.GET.get('q', '').strip()
    country_id = request.GET.get('country', '')
    if q:
        qs = qs.filter(name__icontains=q)
    if country_id.isdigit():
        qs = qs.filter(country_id=int(country_id))
    return render(request, 'tours/tour_list.html', {
        'tours': qs,
        'countries': Country.objects.all(),
        'search_query': q,
        'selected_country': country_id,
    })


def tour_detail(request, pk):
    tour = get_object_or_404(
        Tour.objects.select_related('country'), pk=pk
    )
    return render(request, 'tours/tour_detail.html', {'tour': tour})

def tour_create(request):
    """Заглушка: создание тура (реализуем позже через CBV)."""
    return render(request, 'tours/tour_form.html', {})

def booking_create(request):
    tours = Tour.objects.filter(is_active=True).select_related('country')
    clients = Client.objects.all()

    if request.method == 'POST':
        errors = {}
        values = request.POST

        tour_id = request.POST.get('tour', '')
        client_id = request.POST.get('client', '')
        start = request.POST.get('start_date', '')
        end = request.POST.get('end_date', '')

        tour = None
        if not tour_id.isdigit():
            errors['tour'] = 'Выберите тур.'
        else:
            tour = Tour.objects.filter(pk=int(tour_id), is_active=True).first()
            if tour is None:
                errors['tour'] = 'Тур не найден.'

        client = None
        if not client_id.isdigit():
            errors['client'] = 'Выберите клиента.'
        else:
            client = Client.objects.filter(pk=int(client_id)).first()
            if client is None:
                errors['client'] = 'Клиент не найден.'

        try:
            y, m, d = map(int, start.split('-'))
            start_d = date(y, m, d)
        except (ValueError, AttributeError):
            errors['start_date'] = 'Некорректная дата начала.'
            start_d = None

        try:
            y, m, d = map(int, end.split('-'))
            end_d = date(y, m, d)
        except (ValueError, AttributeError):
            errors['end_date'] = 'Некорректная дата окончания.'
            end_d = None

        if start_d and end_d and end_d < start_d:
            errors['end_date'] = 'Дата окончания раньше даты начала.'

        # --- расчёт суммы ---
        total_price = Decimal('0')
        if tour and start_d and end_d:
            nights = (end_d - start_d).days
            if nights <= 0:
                errors['end_date'] = 'Минимум 1 день.'
            else:
                total_price = tour.price * nights

        if not errors:
            with transaction.atomic():
                booking = Booking.objects.create(
                    tour=tour,
                    client=client,
                    start_date=start_d,
                    end_date=end_d,
                    total_price=total_price,
                    status='new',
                )
            messages.success(
                request,
                f'Бронирование №{booking.pk} создано. Сумма: {total_price} ₽'
            )
            return redirect('tours:booking_success', pk=booking.pk)

        return render(request, 'tours/booking_form.html', {
            'tours': tours,
            'clients': clients,
            'errors': errors,
            'values': values,
        }, status=400)

    # GET — пустая форма
    return render(request, 'tours/booking_form.html', {
        'tours': tours,
        'clients': clients,
        'errors': {},
        'values': {},
    })


def booking_success(request, pk):
    booking = get_object_or_404(
        Booking.objects.select_related('tour', 'client'), pk=pk
    )
    return render(request, 'tours/booking_success.html', {'booking': booking})