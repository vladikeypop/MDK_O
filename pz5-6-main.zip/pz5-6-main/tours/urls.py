from django.urls import path
from . import views

app_name = 'tours'

urlpatterns = [
    path('', views.tour_list, name='tour_list'),
    path('create/', views.tour_create, name='tour_create'),
    path('bookings/create/', views.booking_create, name='booking_create'),
    path('bookings/<int:pk>/success/', views.booking_success, name='booking_success'),
    path('<int:pk>/', views.tour_detail, name='tour_detail'),
]