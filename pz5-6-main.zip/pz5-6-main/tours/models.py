from django.db import models
from django.core.validators import MinValueValidator, RegexValidator


class Country(models.Model):
    VISA_CHOICES = [
        ('none', 'Без визы'),
        ('required', 'Нужна виза'),
        ('evisa', 'Электронная виза'),
    ]

    name = models.CharField('Название', max_length=100, unique=True)
    visa_regime = models.CharField(
        'Визовый режим', max_length=20, choices=VISA_CHOICES, default='none'
    )
    currency = models.CharField('Валюта', max_length=20)

    class Meta:
        verbose_name = 'Страна'
        verbose_name_plural = 'Страны'
        ordering = ['name']

    def __str__(self):
        return self.name


class Tour(models.Model):
    name = models.CharField('Название', max_length=200)
    country = models.ForeignKey(
        Country, on_delete=models.CASCADE,
        related_name='tours', verbose_name='Страна'
    )
    duration_days = models.PositiveIntegerField(
        'Длительность, дней',
        validators=[MinValueValidator(1)]
    )
    price = models.DecimalField(
        'Цена, ₽', max_digits=10, decimal_places=2,
        validators=[MinValueValidator(0)]
    )
    description = models.TextField('Описание', blank=True)
    is_active = models.BooleanField('Активен', default=True)
    created_at = models.DateTimeField('Создан', auto_now_add=True)

    class Meta:
        verbose_name = 'Тур'
        verbose_name_plural = 'Туры'
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.name} ({self.country.name})'


class Client(models.Model):
    full_name = models.CharField('ФИО', max_length=200)
    passport = models.CharField(
        'Паспорт', max_length=20, unique=True,
        validators=[RegexValidator(r'^\d{4}\s?\d{6}$', 'Формат: 1234 567890')],
    )
    phone = models.CharField('Телефон', max_length=20)
    email = models.EmailField('Email')

    class Meta:
        verbose_name = 'Клиент'
        verbose_name_plural = 'Клиенты'
        ordering = ['full_name']

    def __str__(self):
        return self.full_name


class Booking(models.Model):
    STATUS_CHOICES = [
        ('new', 'Новое'),
        ('paid', 'Оплачено'),
        ('cancelled', 'Отменено'),
    ]

    tour = models.ForeignKey(
        Tour, on_delete=models.PROTECT,
        related_name='bookings', verbose_name='Тур'
    )
    client = models.ForeignKey(
        Client, on_delete=models.CASCADE,
        related_name='bookings', verbose_name='Клиент'
    )
    start_date = models.DateField('Дата начала')
    end_date = models.DateField('Дата окончания')
    total_price = models.DecimalField(
        'Сумма, ₽', max_digits=10, decimal_places=2,
        validators=[MinValueValidator(0)]
    )
    status = models.CharField(
        'Статус', max_length=20, choices=STATUS_CHOICES, default='new'
    )
    created_at = models.DateTimeField('Создано', auto_now_add=True)

    class Meta:
        verbose_name = 'Бронирование'
        verbose_name_plural = 'Бронирования'
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.tour.name} — {self.client.full_name}'