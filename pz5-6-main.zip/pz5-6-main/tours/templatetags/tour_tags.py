from django import template
from django.db.models import Count, Avg
from tours.models import Tour, Country, Booking

register = template.Library()


@register.simple_tag
def total_tours():
    return Tour.objects.filter(is_active=True).count()


@register.simple_tag
def average_price():
    result = Tour.objects.aggregate(avg=Avg('price'))
    return result['avg'] or 0


@register.inclusion_tag('tours/tags/popular_tours.html')
def show_popular_tours(count=3):
    tours = (
        Tour.objects.filter(is_active=True)
        .annotate(bookings_count=Count('bookings'))
        .order_by('-bookings_count')[:count]
    )
    return {'tours': tours}


@register.inclusion_tag('tours/tags/country_filter.html', takes_context=True)
def show_country_filter(context):
    return {
        'countries': Country.objects.all(),
        'selected_country': context.get('selected_country', ''),
        'request': context['request'],
    }


@register.filter
def currency(value):
    try:
        return f"{value:.2f} ₽"
    except (ValueError, TypeError):
        return value


@register.filter
def duration_label(days):
    try:
        d = int(days)
        if d <= 3:
            return 'Короткий'
        elif d <= 7:
            return 'Стандарт'
        return 'Длительный'
    except (ValueError, TypeError):
        return ''